<?php 
$nik = "PANEL BY SENDYHOST⚡";
$sender = "sendyhostvip@gmail.com";
?>