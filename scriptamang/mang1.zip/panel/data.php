<?php 
$nik = "WEB SENDYHOST";
$sender = "sendyhostvip@gmail.com";
?>